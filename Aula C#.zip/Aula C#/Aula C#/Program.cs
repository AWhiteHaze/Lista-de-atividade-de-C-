﻿namespace Aula_C_
{
    internal class Program
    {
        public static void Main()
        {
            Console.WriteLine("Bem Vindo(a)!");
            Console.WriteLine("Vamos verificar sua idade e quantos anos terá em 2050.");

            Console.Write("Por favor informe seu nome: ");
            String nome = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(nome))
            {
                Console.WriteLine("Erro: nome não pode ser vazio.");
                return; 
            }

            Console.Write("Agora Informe seu ano de nascimento: ");
                int anoN = int.Parse(Console.ReadLine());

                if (anoN <= 0) { Console.WriteLine("Voce não informou seu ano de nascimento corretamente"); }
                
                Console.Write("Informa o ano atual: ");
                int anoA = int.Parse(Console.ReadLine());

                int idade = anoA - anoN;
                int idadeEm2050 = 2050 - anoN;

                Console.WriteLine($"\nOlá, {nome}!");
                Console.WriteLine($"Sua idade atual é: {idade} anos.");
                Console.WriteLine($"Em 2050, você terá: {idadeEm2050} anos.");

                Console.ReadKey();

        }
    }


}