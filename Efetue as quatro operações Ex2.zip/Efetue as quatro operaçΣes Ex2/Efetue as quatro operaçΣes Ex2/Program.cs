﻿namespace Efetue_as_quatro_operações_Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}