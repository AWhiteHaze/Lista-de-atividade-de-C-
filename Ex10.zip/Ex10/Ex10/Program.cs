﻿namespace Media_Aluno_Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Informe nome do Aluno: ");
            string nome = Console.ReadLine();

            Console.Write("Informe o numero de faltas: ");
            double faltas = double.Parse(Console.ReadLine());

            Console.Write("Informe a 1° nota: ");
            double nota1 = double.Parse(Console.ReadLine());

            Console.Write("Informe a 2° nota: ");
            double nota2 = double.Parse(Console.ReadLine());

            Console.Write("Informe a 3° nota: ");
            double nota3 = double.Parse(Console.ReadLine());

            var media = (nota1 + nota2 + nota3) / 3;



            if (media >= 5.0 && faltas <= 27)
            {
                Console.WriteLine($"O aluno {nome} esta aprovado(a) !");
            }
            else if (media < 5.0)
            {
                Console.WriteLine($"O aluno {nome} foi reprovado por media !");
            }
            else
            {
                Console.WriteLine($"O aluno {nome} foi reprovado por Falta !");
            }

            Console.ReadKey();


        }
    }
}