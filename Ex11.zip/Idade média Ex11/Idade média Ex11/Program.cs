﻿using System;

namespace IdadeMediaEMaisVelho
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int quantidadePessoas = 5;
            string nomeMaisVelho = "";
            int idadeMaisVelho = 0;
            int somaIdades = 0;

            for (int i = 1; i <= quantidadePessoas; i++)
            {
                Console.WriteLine($"Pessoa {i}:");

                Console.Write("Informe o nome: ");
                string nome = Console.ReadLine();

                Console.Write("Informe a idade: ");
                int idade = int.Parse(Console.ReadLine());

                somaIdades += idade;

                if (idade > idadeMaisVelho)
                {
                    idadeMaisVelho = idade;
                    nomeMaisVelho = nome;
                }

                Console.WriteLine(); 
            }

            double media = somaIdades / (double)quantidadePessoas;

            Console.WriteLine($"Idade média: {media:F2}");
            Console.WriteLine($"Pessoa mais velha: {nomeMaisVelho} com {idadeMaisVelho} anos");

            Console.ReadKey();
        }
    }
}
