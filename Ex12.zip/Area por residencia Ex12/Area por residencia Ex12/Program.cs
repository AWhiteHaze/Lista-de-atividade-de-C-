﻿using System;

namespace AreaResidencia
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double areaTotal = 0;

            while (true)
            {
                Console.Write("Informe o nome do cômodo: ");
                string nomeComodo = Console.ReadLine();

                Console.Write("Informe a largura do cômodo (em metros): ");
                double largura = double.Parse(Console.ReadLine());

                Console.Write("Informe o comprimento do cômodo (em metros): ");
                double comprimento = double.Parse(Console.ReadLine());

                double areaComodo = largura * comprimento;
                areaTotal += areaComodo;

                Console.WriteLine($"Área do cômodo {nomeComodo}: {areaComodo:F2} m²");

                Console.Write("Deseja adicionar outro cômodo? (sim/não): ");
                string resposta = Console.ReadLine().Trim().ToLower();

                if (resposta != "sim")
                {
                    break;
                }

                Console.WriteLine(); // linha em branco para separar as entradas
            }

            Console.WriteLine($"\nÁrea total da residência: {areaTotal:F2} m²");
            Console.ReadKey();
        }
    }
}
