﻿using System;

namespace TrocaVetor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            int[] vetor = new int[16];

            Console.WriteLine("Informe os 16 valores para o vetor:");
            for (int i = 0; i < 16; i++)
            {
                Console.Write($"Vetor:  {i + 1}: ");
                vetor[i] = int.Parse(Console.ReadLine());
            }

            
            Console.WriteLine("\nVetor original:");
            MostrarVetor(vetor);

            
            for (int i = 0; i < 8; i++)
            {
                int temp = vetor[i];
                vetor[i] = vetor[i + 8];
                vetor[i + 8] = temp;
            }

            Console.WriteLine("\nVetor após a troca:");
            MostrarVetor(vetor);

            Console.ReadKey();
        }

        static void MostrarVetor(int[] vetor)
        {
            foreach (int valor in vetor)
            {
                Console.Write(valor + " ");
            }
            Console.WriteLine();
        }
    }
}
