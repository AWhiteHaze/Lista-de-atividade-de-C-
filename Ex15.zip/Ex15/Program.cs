﻿using static System.Runtime.InteropServices.JavaScript.JSType;

class pares
{
    public static void Main()
    {
        int pares = 0;
        int i = 0;
        int[] numeros = new int[40];
        while (i < 40)
        {
            Console.Write($"Digite o {i + 1}º número: ");
            string entrada = Console.ReadLine();
            numeros[i] = int.Parse(entrada);
            i++;
        }
        Console.WriteLine();
        for (i = 0; i < numeros.Length; i++)
        {
            if (numeros[i] % 2 == 0)
            {
                pares++;
            }
        }
        Console.WriteLine($"Tem {pares} numeros pares!");
    }
}