﻿class mediaalturamen
{
    public static void Main()
    {
        int i = 0;
        double MenorH = 0;
        double MaiorH = 0;

        double TotalT = 0;
        double MediaT = 0;

        double TotalF = 0;
        double MediaF = 0;
        int qtdF = 0;
        int qtdM = 0;
        while (i < 7)
        {
            Console.Write($"Digite o sexo da {i + 1}º pessoa (M/F): ");
            string sexo = Console.ReadLine().ToUpper();
            Console.Write($"Digite a altura da {i + 1}º pessoa: ");
            double H = double.Parse(Console.ReadLine());

            if (H > MaiorH)
            {
                MaiorH = H;
            }

            if (i == 0)
            {
                MenorH = H;
            }

            if (H < MenorH)
            {
                MenorH = H;
            }

            if (sexo == "F")
            {
                TotalF += H;

                qtdF++;
            }

            TotalT += H;

            if (sexo == "M")
            {
                qtdM++;
            }

            i++;    
        }
        MediaF = TotalF / qtdF;
        MediaT = TotalT / 7;
        Console.WriteLine($"\nMaior altura      : {MaiorH:F2} m");
        Console.WriteLine($"Menor altura        : {MenorH:F2} m");
        Console.WriteLine($"\nMedia das mulheres: {MediaF:F2} m");
        Console.WriteLine($"\nMedia do grupo    : {MediaT:F2} m");
        Console.WriteLine($"\nTotal de homens   : {qtdM}");
    }
}