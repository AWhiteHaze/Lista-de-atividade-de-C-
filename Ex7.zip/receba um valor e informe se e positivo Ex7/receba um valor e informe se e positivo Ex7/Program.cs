﻿namespace receba_um_valor_e_informe_se_e_positivo_Ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Informe um valor: ");
            float valor = float.Parse(Console.ReadLine());

            if (valor <= 0)
            {
                Console.WriteLine("O valor não e positivo");
            }
            if (valor >= 1)
            {
                Console.WriteLine("O valor e positivo");
            }

            Console.ReadKey();  
        }
    }
}