﻿namespace Quantas_raízes_reais_Ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Informe o coeficiente a: ");
            float a = float.Parse(Console.ReadLine());

            Console.Write("Informe o coeficiente b: ");
            float b = float.Parse(Console.ReadLine());

            Console.Write("Informe o coeficiente c: ");
            float c = float.Parse(Console.ReadLine());

           float Delta = b*b -4*a*c;

            if (Delta > 0)
            {
                Console.WriteLine("A equação possui 2 raízes reais.");
            }
            else if (Delta == 0)
            {
                Console.WriteLine("A equação possui 1 raiz real.");
            }
            else 
            {
                Console.WriteLine("A equação não possui raízes reais.");
            }

            Console.ReadKey();  

        }
    }
}