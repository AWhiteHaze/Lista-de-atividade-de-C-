﻿namespace Altura_e_peso_por_genero_Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Informe nome: ");
            string nome = Console.ReadLine();

            Console.Write("Informe seu genero (Em M ou F): ");
            string genero = Console.ReadLine().ToUpper();

            Console.Write("Informe sua Altura (Em metros): ");
            float altura = float.Parse(Console.ReadLine());




            if (genero != "M" && genero != "F") 
            {
              Console.WriteLine($"{nome} seu genero e invalido por favor ente novamente");
              return;
            }


            double pesoIdeal;

            if (genero == "M")
            {
                pesoIdeal = (72.7 * altura) - 58;
            }
            else 
            {
                pesoIdeal = (62.1 * altura) - 44.7;
            }

            Console.WriteLine($"{nome}, seu peso ideal é: {pesoIdeal:F2} kg.");

            Console.ReadKey();  



        }
    }
}