﻿namespace Exercicio_p3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculadora de salário");

            Console.Write("Informe seu Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Informe seu Salário base: ");
            float salariob = float.Parse(Console.ReadLine());


            float gratifica = salariob * 0.05f;


            float imposto = salariob * 0.07f;


            float salariof = (salariob + gratifica) - imposto;


            Console.WriteLine($"{nome}, seu salário base é de: R$ {salariob:F2}");
            Console.WriteLine($"Seu salário a ser recebido é de: R$ {salariof:F2}");
        }
    }
}
