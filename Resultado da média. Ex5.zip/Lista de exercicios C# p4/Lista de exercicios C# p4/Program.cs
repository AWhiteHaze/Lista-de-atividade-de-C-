﻿namespace Lista_de_exercicios_C__p4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Entrada dos valores
            Console.WriteLine("Digite o primeiro valor:");
            double valor1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o segundo valor:");
            double valor2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o terceiro valor:");
            double valor3 = double.Parse(Console.ReadLine());

            int peso1 = 3;
            int peso2 = 3;
            int peso3 = 4;


            double mediaPonderada = (valor1 * peso1 + valor2 * peso2 + valor3 * peso3) / (peso1 + peso2 + peso3);

            Console.WriteLine("A média ponderada é: " + mediaPonderada.ToString("F2"));
        }
    }

}